<?php
 $db_host="localhost"; 
 $db_user="root";
 $db_pwd="";
 $db_name="gymfit";
?>